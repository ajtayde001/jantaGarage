import React from 'react'

const Footer = () => {
  return (
    <div style={{height:"50px"}}>
        <p style={{margin:"auto",marginTop:"15px"}} >Powered by Fusionloop Solution</p>
        
    </div>
  )
}

export default Footer