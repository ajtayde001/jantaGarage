import React from 'react'

const ViewerHome = () => {
  return (
    <div>ViewerHome</div>
  )
}

export default ViewerHome