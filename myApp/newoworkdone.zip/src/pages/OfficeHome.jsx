import React from 'react'

const OfficeHome = () => {
  return (
    <div>OfficeHome</div>
  )
}

export default OfficeHome