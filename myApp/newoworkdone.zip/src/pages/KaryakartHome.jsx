import React from 'react'

const Karyakart = () => {
  return (
    <div>Karyakart</div>
  )
}

export default Karyakart